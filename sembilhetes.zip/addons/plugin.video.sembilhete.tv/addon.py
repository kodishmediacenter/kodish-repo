#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright 2016 SemBilhete.tv

import sys
import sembilhete

sembilhete.main()
